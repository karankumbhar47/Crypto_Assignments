### Question 1
- Make `question1.sh` file executable
```bash
chmod +x question1.sh
```
- Run the script with two arugument
    - first : keyPath
    - second : password
    ```bash
    ./question1.sh <keypath> <password>
    ```
- random number output from script is as follows
    - `3b4a8385707ecf88f1dcce7d1a28dcfa`

### Question 2
- Make `question2.sh` file executable
```bash
chmod +x question2.sh
```
- Run the script with following arugument
    - first : certificate path
    ```bash
    ./question2.sh <certificate path> 
    ```
- output will be dumped in `output.txt` file