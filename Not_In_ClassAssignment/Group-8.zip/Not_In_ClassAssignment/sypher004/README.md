## Sypher004

- Run python file `generate.py`
- Enter the number of rounds.
- After execucation is completed following two files are generated
    - sypher004.lp
    - solution.sol
